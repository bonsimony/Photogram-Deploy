package com.cos.photogramstart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotogramStartApplicationTests {

	@Test
	void contextLoads() {
	}

}
